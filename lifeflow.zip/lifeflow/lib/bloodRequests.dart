import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
import 'package:intl/intl.dart';

import 'mymodel.dart';
import 'oldrequestremove.dart';

class LocalUser {
  String name;
  String email;
  bool online;
  String profilePhotoUrl;
  String bloodType;
  String phoneNumber;
  String district;

  LocalUser({
    required this.name,
    required this.email,
    required this.online,
    required this.profilePhotoUrl,
    required this.bloodType,
    required this.district,
    required this.phoneNumber, required isDonationEnabled,
  });
}

class BloodRequestScreen extends StatefulWidget {
  @override
  _BloodRequestScreenState createState() => _BloodRequestScreenState();
}

class _BloodRequestScreenState extends State<BloodRequestScreen> {
  late Timer _timer;

  @override
  void initState() {
    super.initState();

    // Schedule the timer to run every day
    _timer = Timer.periodic(const Duration(days: 1), (timer) {
      BloodRequestHelper.removeOldBloodRequests();
    });
  }

  @override
  void dispose() {
    _timer.cancel(); // Cancel the timer when the widget is disposed
    super.dispose();
  }

  final int _perPage = 10; // Number of requests to fetch per page
  DocumentSnapshot? _lastDocument;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleTextStyle: TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 25,
          color: Colors.black,
        ),
        title: const Text('Recent Requests'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: _getBloodRequestsStream(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          List<BloodRequest> bloodRequests = snapshot.data!.docs.map((doc) {
            return BloodRequest.fromMap(doc.data() as Map<String, dynamic>, doc.id);
          }).toList();
          bloodRequests.sort((a, b) => b.timestamp.compareTo(a.timestamp));

          return bloodRequests.isEmpty
              ? const Center(
            child: Text(
              'No blood requests available',
              style: TextStyle(fontSize: 16),
            ),
          )
              : ListView.builder(
            itemCount: bloodRequests.length + 1,
            itemBuilder: (context, index) {
              if (index == bloodRequests.length) {
                return _buildLoadMoreButton(bloodRequests.length, snapshot.data!);
              } else {
                var request = bloodRequests[index];
                return BloodRequestCard(request: request);
              }
            },
          );
        },
      ),
    );
  }

  Stream<QuerySnapshot> _getBloodRequestsStream() {
    Query query = FirebaseFirestore.instance
        .collection('blood_requests')
        .orderBy('timestamp', descending: true) // Order by timestamp in descending order
        .limit(_perPage); // Limit the initial fetch

    if (_lastDocument != null) {
      query = query.startAfterDocument(_lastDocument!); // Start after the last document of the previous page
    }

    return query.snapshots();
  }

  Widget _buildLoadMoreButton(int currentCount, QuerySnapshot snapshot) {
    return InkWell(
      onTap: () {
        _loadMore(currentCount, snapshot);
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: MediaQuery.of(context).size.height * 0.02),
        alignment: Alignment.center,
        child: const Text(
          'Load More',
          style: TextStyle(color: Colors.blue, fontSize: 16),
        ),
      ),
    );
  }

  void _loadMore(int currentCount, QuerySnapshot snapshot) {
    setState(() {
      _lastDocument = snapshot.docs[currentCount - 1];
    });
  }
}

class BloodRequestCard extends StatelessWidget {
  final BloodRequest request;

  BloodRequestCard({required this.request});

  @override
  Widget build(BuildContext context) {
    // Format the timestamp to display both date and time
    String formattedDateTime = DateFormat('dd/MM/yyyy hh:mm a').format(request.timestamp);

    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(
        horizontal: MediaQuery.of(context).size.width * 0.04,
        vertical: MediaQuery.of(context).size.height * 0.015,
      ),
      child: ListTile(
        title: Text(
          request.userName,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: MediaQuery.of(context).size.height * 0.01),
            Text(
              'Blood Group: ${request.bloodGroup}',
              style: const TextStyle(fontSize: 16),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.01),
            Text(
              'District: ${request.district}',
              style: const TextStyle(fontSize: 16),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.01),
            Text(
              'Request Time: $formattedDateTime',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
        trailing: ElevatedButton(
          onPressed: () {
            _makePhoneCall(request.contactNumber, context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          child: const Icon(Icons.phone),
        ),
      ),
    );
  }

  void _makePhoneCall(String? phoneNumber, BuildContext context) async {
    if (phoneNumber == null || phoneNumber.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Phone number is not available')),
      );
      return;
    }

    await FlutterPhoneDirectCaller.callNumber(phoneNumber);
    // Handle the result if needed; the package doesn't return a boolean value
  }
}
