// import 'package:flutter/material.dart';
//
// Color orangeColors = Color(0xffF5591F);
// Color orangeLightColors = Color(0xffF2861E);
// Color Brightblue= Color(51e2f5);
//
// Color BlueGreen= 9df9ef
//
// Color DustyWhite= edf756
//
// Color PinkSand= ffa8B6
//
// Color DarkSand=a28089