import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'HomeScreen.dart';
import 'LoginScreen.dart';
import 'messaging service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> {
  final messagingService = MessagingService();

  @override
  void initState() {
    super.initState();
    messagingService.init(context);
    _checkUserAuthentication();
  }

  Future<void> _checkUserAuthentication() async {
    final user = FirebaseAuth.instance.currentUser;

    // Wait for 2 seconds to show the splash screen
    await Future.delayed(const Duration(seconds: 2));

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => user != null ? MyHomeScreen(userId: '',) : const LoginScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: const Color(0xFF4A148C),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 75,
                backgroundColor: Colors.transparent,
                backgroundImage: AssetImage("assets/blood.jpeg"),
              ),
              const SizedBox(height: 20),
              const Text(
                "Life Flow",
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  letterSpacing: 2.0,
                  fontFamily: 'Pacifico',
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                "Connecting Blood Donors\nFor Rapid Emergencies",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white70,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
