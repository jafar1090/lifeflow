package com.example.lifeflow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
